//
//  ViewControllerExtension.swift
//  TastyFingersApp
//
//  Created by Appit on 06/11/18.
//  Copyright © 2018 Tasty Fingers. All rights reserved.
//

import Foundation
import  UIKit



extension UIViewController {
    
    // Alert controller with title
    
    func showAlert(title:String? , message:String?) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK" , style: .default, handler: nil)
        alertController.addAction(defaultAction)
        DispatchQueue.main.async {
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
    // Alert controller with title and action
    
    func showAlert(title:String? , message:String?, action:Selector?, showCancel:Bool? = true,okayTitle:String?,cancelTitle:String?) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: okayTitle , style: .default, handler: { alert in
            
            if action != nil {
                self.perform(action)
            }
        })
        let cancelAction = UIAlertAction(title: cancelTitle , style: .default, handler: nil)
        if showCancel == true {
            alertController.addAction(cancelAction)
        }
        alertController.addAction(okAction)
        DispatchQueue.main.async {
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
}
