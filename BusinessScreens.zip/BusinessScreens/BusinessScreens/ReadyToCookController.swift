//
//  ReadyToCookController.swift
//  tastyFingers
//
//  Created by Brahmaiah Chowdary on 08/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class ReadyToCookController: UIViewController,UISearchBarDelegate {
    
    let imagesArray2 = ["1","2","3","4","5","6","1","2","3","4","5","6","1","2","3","4","5","6","1","2","3","4","5","6","1","2","3","4","5","6","1","2","3","4","5","6"]
    let itemsArray2 = ["ChickenTikka","ChickenCheese","PineApple","ChickenWithBacon","VegetableSalad","MangoChipotle","ChickenTikka","ChickenCheese","PineApple","ChickenWithBacon","VegetableSalad","MangoChipotle","ChickenTikka","ChickenCheese","PineApple","ChickenWithBacon","VegetableSalad","MangoChipotle","ChickenTikka","ChickenCheese","PineApple","ChickenWithBacon","VegetableSalad","MangoChipotle","ChickenTikka","ChickenCheese","PineApple","ChickenWithBacon","VegetableSalad","MangoChipotle","ChickenTikka","ChickenCheese","PineApple","ChickenWithBacon","VegetableSalad","MangoChipotle"]

    @IBOutlet weak var cookSearchBar: UISearchBar!
    @IBOutlet weak var itemsCollectionsView2: UICollectionView!
     let numberOfCellsPerRow: CGFloat = 3
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let flowLayout = itemsCollectionsView2?.collectionViewLayout as? UICollectionViewFlowLayout {
            let horizontalSpacing = flowLayout.scrollDirection == .horizontal ? flowLayout.minimumInteritemSpacing : flowLayout.minimumLineSpacing
            let cellWidth = (view.frame.width - max(0, numberOfCellsPerRow - 1)*horizontalSpacing)/numberOfCellsPerRow
            flowLayout.itemSize = CGSize(width: cellWidth, height: cellWidth)
            
            cookSearchBar.delegate = self
            itemsCollectionsView2.delegate = self
            itemsCollectionsView2.dataSource = self
            
    }
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

// MARK:- UICollectionView datasource and delegate methods

extension ReadyToCookController: UICollectionViewDataSource,UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemsArray2.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell2 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath) as! ReadyToCookCell
        cell2.cookLbl.text = itemsArray2[indexPath.row]
        cell2.cookImg.image = UIImage(named:imagesArray2[indexPath.row])
        return cell2
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "DetailCookViewController") as! DetailCookViewController

        let strImageName = imagesArray2[indexPath.row]
        let strLblName = itemsArray2[indexPath.row]
        ViewController.strImageName = strImageName
        ViewController.strLblName = strLblName
        
        self.navigationController?.pushViewController(ViewController, animated: true)
        
         print(indexPath.row)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let yourWidth = collectionView.bounds.width/3.0
        let yourHeight = yourWidth
        
        return CGSize(width: yourWidth, height: yourHeight)
        
    }
}



