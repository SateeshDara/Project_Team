//
//  CookViewController.swift
//  collectionDemo
//
//  Created by Brahmaiah Chowdary on 29/10/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class DetailCookViewController: UIViewController {

     var strImageName : String! = nil
    var strLblName : String! = nil
    
    @IBOutlet weak var Img: UIImageView!
    @IBOutlet weak var detailItemName: UILabel!
    @IBOutlet weak var detailItemCost: UILabel!
    @IBOutlet weak var detailAvialableDate: UILabel!
    @IBOutlet weak var detailBestBeforeUse: UILabel!
    @IBOutlet weak var directDisplayItems: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.Img?.image = UIImage(named : strImageName!)
        self.detailItemName?.text = strLblName!
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cartButtonAction(_ sender: Any) {
        let cartviewcontrol = self.storyboard?.instantiateViewController(withIdentifier: "CartTableViewController") as! CartTableViewController
        cartviewcontrol.Img = (Img.image)!
        cartviewcontrol.detailItemName = detailItemName.text!
        
        self.navigationController?.pushViewController(cartviewcontrol, animated: true)
    }
    @IBAction func buyButtonAction(_ sender: Any) {
        
    }
    
}
