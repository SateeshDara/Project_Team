//
//  TransitmediaRegistration.swift
//  BusinessScreens
//
//  Created by chennakesavulu on 13/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class TransitmediaRegistration: UIViewController,UIPickerViewDelegate ,UIPickerViewDataSource{
    // Mark:- Outlets
    
    @IBOutlet var fromTxtField: UITextField!
    @IBOutlet var toTxtField: UITextField!
    @IBOutlet var fromTimeTxtField: UITextField!
    @IBOutlet var toTimeTxtField: UITextField!
    @IBOutlet var vehicleNumberTxtField: UITextField!
    @IBOutlet var vehicleTypeTxtField: UITextField!
    @IBOutlet var idLabel: UILabel!
    @IBOutlet var vehicleImg: UIImageView!
    
    var vehicleArr = ["Two Wheeler","Three Wheeler","Four Wheeler","Truck","Other Catogory"]
    var pickerview = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        self.pickerview.delegate = self
        self.pickerview.dataSource = self
        
        self.vehicleTypeTxtField.inputView = pickerview
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.vehicleArr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
         return self.vehicleArr[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
         self.vehicleTypeTxtField.text! =  self.vehicleArr[row]
    }
}

    extension TransitmediaRegistration: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        
    @IBAction func pickImgAction(_ sender: Any) {
        
        let image = UIImagePickerController()
        image.delegate = self
        image.allowsEditing = false
        image.sourceType = UIImagePickerControllerSourceType.photoLibrary
        // image.sourceType = UIImagePickerControllerSourceType.savedPhotosAlbum
        self.present(image,animated: true,completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage ] as? UIImage
        {
            self.vehicleImg.image = image
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    }


