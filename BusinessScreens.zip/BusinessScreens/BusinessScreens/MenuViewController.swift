//
//  MenuViewController.swift
//  RegView
//
//  Created by Brahmaiah Chowdary on 24/10/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

protocol SlideMenuDelegate
{
    func slideMenuItemSelectedAtIndex(_index:Int32)
}

class MenuViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate {
    
    let UserDefault = UserDefaults.standard
    
    //Mark:- OutLets
    @IBOutlet weak var menuImg: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var id: UILabel!
    @IBOutlet weak var closeBtn: UIButton!
    
    var btnMenu : UIButton!
    var delegate : SlideMenuDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.clear
    //    self.getImage()
       
        let Name = UserDefaults.standard.string(forKey: "Name")
        lblName.text = Name
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
    
    //Mark:- Actions
    @IBAction func btnClose(_ sender: UIButton) {
        
        btnMenu.tag = 0
        btnMenu.isHidden = false
        if (self.delegate != nil) {

            var index = Int32()
                       // Int32[sender.tag]
            if(sender == self.closeBtn){
                index = -1
            }
            delegate?.slideMenuItemSelectedAtIndex(_index: index)
        }
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame = CGRect(x:-UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            self.view.layoutIfNeeded()
            self.view.backgroundColor = UIColor.clear
        },completion: { (finished) -> Void in
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
            
        })
}
    
    @IBAction func editBtn(_ sender: UIButton) {
        let image = UIImagePickerController()
        image.delegate = self
        image.sourceType = UIImagePickerControllerSourceType.photoLibrary
        self.present(image,animated: true,completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage ] as? UIImage {
            self.menuImg.image = image
            
            self.saveImageDocumentDirectory(profileImage: image)
        }
       
        self.dismiss(animated: true, completion: nil)
    }
    
    // MARK: - saveImage in DocumentDirectory
    
    func saveImageDocumentDirectory(profileImage:UIImage){
        
        let fileManager = FileManager.default
        let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("apple.jpg")
       // print(paths)
        let imageData = UIImageJPEGRepresentation(profileImage, 0.5)
        fileManager.createFile(atPath: paths as String, contents: imageData, attributes: nil)
    }
    
    // MARK: - Get directory path
    
    func getDirectoryPath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    
//
//    // MARK: - Get image from directory path
//
//    func getImage(){
//        let fileManager = FileManager.default
//        let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent("apple.jpg")
//        if fileManager.fileExists(atPath: imagePAth){
//            self.menuImg.image = UIImage(contentsOfFile: imagePAth)
//        }else{
//            print("No Image")
//        }
//    }
    
    @IBAction func ordersBtn(_ sender: UIButton) {
         let vc=self.storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func postingsBtn(_ sender: UIButton) {
        
        
//        let vc1=self.storyboard?.instantiateViewController(withIdentifier: "PostViewController") as! PostViewController
//        self.navigationController?.pushViewController(vc1, animated: true)
    }
    
    
    @IBAction func walletBtn(_ sender: Any) {
        let vc2=self.storyboard?.instantiateViewController(withIdentifier: "WalletViewController") as! WalletViewController
        self.navigationController?.pushViewController(vc2, animated: true)
        
    }
    
    @IBAction func logoutBtn(_ sender: UIButton) {
        let alert = UIAlertController(title:title,message:"Do you want Logout.",preferredStyle:UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "ok", style:.default, handler:{_ in
           // let vc2=self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
            //self.present(vc2, animated: true, completion: nil)
            self.navigationController?.popToRootViewController(animated: true)

        }))
        alert.addAction(UIAlertAction(title: "Cancel", style:.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
