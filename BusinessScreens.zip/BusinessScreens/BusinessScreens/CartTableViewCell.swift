//
//  CartTableViewCell.swift
//  collectionDemo
//
//  Created by chennakesavulu on 30/10/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit


class CartTableViewCell: UITableViewCell {
    
   // var MGSwipeButton = String()
    
    @IBOutlet weak var cartImage: UIImageView!
    @IBOutlet weak var cartItemName: UILabel!
    @IBOutlet weak var cartItemCost: UILabel!
    @IBOutlet weak var cartCellCost: UILabel!
    @IBOutlet weak var numofItems: UILabel!
    
    var someValue: Int = 1 {
        didSet {
            numofItems.text = "\(someValue)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
          someValue = 1
       

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
      
        // Configure the view for the selected state
    }
   
    
    @IBAction func plusAction(_ sender: Any) {
       someValue += 1
    }
    @IBAction func minusAction(_ sender: Any) {
        someValue -= 1
    }
   
    @IBAction func deletecartAction(_ sender: Any) {
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
            let delete = UITableViewRowAction(style: .destructive, title: "Delete") { (action, indexPath) in
                // delete item at indexPath
//                self.MGSwipeButton.remove(at: "MGSwipeButton"(indexPath.row))
//                tableView.deleteRows(at: [indexPath], with: .fade)
//                print(self.MGSwipeButton )
//            tableView.deleteRows(at: [indexPath], with: .fade)
//            // tableView.removeFromSuperview()
            tableView.reloadData()
            
        }
      
    }
    

}
}












