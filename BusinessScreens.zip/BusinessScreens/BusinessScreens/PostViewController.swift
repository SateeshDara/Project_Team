//
//  PostingsViewController.swift
//  RegView
//
//  Created by Brahmaiah Chowdary on 25/10/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//
import UIKit


class PostViewController: UIViewController, UINavigationControllerDelegate,UIImagePickerControllerDelegate {
    
    var selectedItemFor: String?
    var selectedperCost: String?
    var selectedType: String?
    var getItem = String()
    
    // Mark:- Outlets
    @IBOutlet weak var itemName: UITextField!
    @IBOutlet weak var itemCost: UITextField!
    @IBOutlet weak var perUnitTxtField: UITextField!
    @IBOutlet weak var avilableQuantity: UITextField!
    @IBOutlet weak var DateTxtField: UITextField!
    @IBOutlet weak var bestBeforeTxtField: UITextField!
    @IBOutlet weak var itemForTxtField: UITextField!
    @IBOutlet weak var itemTypeTxtField: UITextField!
    
    //MARK:- Propeties
    
    let itemForArr = ["Ready To Cook","Ready To Eat","Direct From Farm"]
    let perUnitArr = ["Kg","Litre","Packet","Piece"]
    let itemTypeArr = ["Veg","NonVeg"]
    
    var datePicker = UIDatePicker()
    var datePicker1 = UIDatePicker()
    var pickerView = UIPickerView()
    
    var isFromItemTxtField:Bool = false
    var isFromPerUnitTxtField:Bool = false
    var isFromItemTypeTxtField :Bool = false
    
    // MARK: - Handling date picker
    
    @objc func handleDatePicker(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        DateTxtField.text = dateFormatter.string(from: sender.date)
        
    }
    @objc func handleDatePicker1(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        bestBeforeTxtField.text = dateFormatter.string(from: sender.date)
    }
    
    // MARK: - Override methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
//
//        self.createToolbar()
//        self.createToolbar1()
//        self.createToolbar2()
//        self.createToolbar3()
//        self.createToolbar4()
        
        self.DateTxtField.inputView = datePicker
        self.bestBeforeTxtField.inputView = datePicker1
        self.perUnitTxtField.inputView = pickerView
        self.itemForTxtField.inputView = pickerView
        self.itemTypeTxtField.inputView = pickerView
        
        itemName.text = String(getItem)
        
        //Mark:-Datepickers
        
        datePicker.datePickerMode = UIDatePickerMode.date
        DateTxtField.inputView = datePicker
        
        datePicker.addTarget(self, action: #selector(handleDatePicker(sender:)), for: .valueChanged)
        
        datePicker1.datePickerMode = UIDatePickerMode.date
        bestBeforeTxtField.inputView = datePicker1
        datePicker1.addTarget(self, action: #selector(handleDatePicker1(sender:)), for: .valueChanged)
        
    }
    
    // Mark:- ToolBars
//    func createToolbar()
//    {
//        let toolBar = UIToolbar()
//        toolBar.sizeToFit()
//        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(PostViewController.doneClick))
//        toolBar.setItems([doneButton], animated: false)
//        toolBar.isUserInteractionEnabled = true
//        DateTxtField.inputAccessoryView = toolBar
//    }
//    @objc func doneClick() {
//        view.endEditing(true)
//    }
//
//    func createToolbar1()
//    {
//        let toolBar1 = UIToolbar()
//        toolBar1.sizeToFit()
//        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(PostViewController.doneClick1))
//        toolBar1.setItems([doneButton], animated: false)
//        toolBar1.isUserInteractionEnabled = true
//        itemForTxtField.inputAccessoryView = toolBar1
//    }
//    @objc func doneClick1() {
//        view.endEditing(true)
//    }
//
//    func createToolbar2()
//    {
//        let toolBar2 = UIToolbar()
//        toolBar2.sizeToFit()
//        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(PostViewController.doneClick2))
//        toolBar2.setItems([doneButton], animated: false)
//        toolBar2.isUserInteractionEnabled = true
//        bestBeforeTxtField.inputAccessoryView = toolBar2
//    }
//    @objc func doneClick2() {
//        view.endEditing(true)
//    }
//    func createToolbar3()
//    {
//        let toolBar3 = UIToolbar()
//        toolBar3.sizeToFit()
//        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(PostViewController.doneClick3))
//        toolBar3.setItems([doneButton], animated: false)
//        toolBar3.isUserInteractionEnabled = true
//        perUnitTxtField.inputAccessoryView = toolBar3
//    }
//    @objc func doneClick3() {
//        view.endEditing(true)
//    }
//    func createToolbar4()
//    {
//        let toolBar4 = UIToolbar()
//        toolBar4.sizeToFit()
//        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(PostViewController.doneClick4))
//        toolBar4.setItems([doneButton], animated: false)
//        toolBar4.isUserInteractionEnabled = true
//        itemTypeTxtField.inputAccessoryView = toolBar4
//    }
//    @objc func doneClick4() {
//        view.endEditing(true)
//    }
    
    // Mark:- Close keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    // Mark:- ImagePicker
    
    @IBOutlet weak var itemImage: UIImageView! {
        didSet{
            self.itemImage.layer.cornerRadius = 30
            self.itemImage.clipsToBounds = true
        }
    }
    @IBAction func eidtAction(_ sender: UIButton) {
        
        let image = UIImagePickerController()
        image.delegate = self
        image.allowsEditing = false
        image.sourceType = UIImagePickerControllerSourceType.photoLibrary
        // image.sourceType = UIImagePickerControllerSourceType.savedPhotosAlbum
        self.present(image,animated: true,completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage ] as? UIImage
        {
            itemImage.image = image
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func previewAction(_ sender: Any) {
        
        let sb: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let popview = sb.instantiateViewController(withIdentifier: "PopUpViewController") as! PopUpViewController
        
        popview.getName = itemName.text!
        popview.getCost = itemCost.text!
        popview.getUnit = perUnitTxtField.text!
        popview.getQuantity = avilableQuantity.text!
        popview.getavlDate = DateTxtField.text!
        popview.getbestBefore = bestBeforeTxtField.text!
        popview.getItemFor = itemForTxtField.text!
        popview.getType = itemTypeTxtField.text!
        if itemImage.image != nil{
            popview.getImage = itemImage.image!
        }
    
        self.addChildViewController(popview)
        self.view.addSubview(popview.view)
        popview.didMove(toParentViewController: self)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    
}
extension PostViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField.tag == 2 {
            
            self.isFromPerUnitTxtField = true
            self.isFromItemTxtField = false
            self.isFromItemTypeTxtField = false
            
            
        } else if textField.tag == 6 {
            
            self.isFromItemTxtField = true
            self.isFromPerUnitTxtField = false
            self.isFromItemTypeTxtField = false
            
        }
        else if textField.tag == 8 {
            
            self.isFromItemTypeTxtField = true
            self.isFromItemTxtField = false
            self.isFromPerUnitTxtField = false
            
        }
        pickerView.delegate = self
        pickerView.dataSource = self
        
    }
    
}


extension PostViewController: UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if self.isFromPerUnitTxtField {
            return self.perUnitArr.count
        }
        else if self.isFromItemTxtField {
            return self.itemForArr.count
        }
        else {
            return self.itemTypeArr.count
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if self.isFromPerUnitTxtField {
            return self.perUnitArr[row]
        }
            
        else if self.isFromItemTxtField {
            return self.itemForArr[row]
        }
        else {
            return self.itemTypeArr[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if self.isFromPerUnitTxtField{
            selectedperCost = perUnitArr[row]
            self.perUnitTxtField.text = perUnitArr[row]
        }
            
        else if self.isFromItemTxtField {
            selectedItemFor = itemForArr[row]
            self.itemForTxtField.text = itemForArr[row]
            
        }
        else {
            selectedType = itemTypeArr[row]
            self.itemTypeTxtField.text = itemTypeArr[row]
            
        }
        
    }
    
}

