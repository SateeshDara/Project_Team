//
//  DirectFromFarmController.swift
//  tastyFingers
//
//  Created by Brahmaiah Chowdary on 08/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class DirectFromFarmController: UIViewController,UISearchBarDelegate {
    
  let imagesArray = ["Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard"]
    let itemsArray = ["Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard","Alu","Bitter","Brinjal","Carrot","cauliflower","cucumber","Swiss-chard"]
    
    
    
    @IBOutlet weak var directSearchBar: UISearchBar!
    @IBOutlet weak var ItemsCollectionsView: UICollectionView!
     let numberOfCellsPerRow: CGFloat = 3
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let flowLayout = ItemsCollectionsView?.collectionViewLayout as? UICollectionViewFlowLayout {
            let horizontalSpacing = flowLayout.scrollDirection == .horizontal ? flowLayout.minimumInteritemSpacing : flowLayout.minimumLineSpacing
            let cellWidth = (view.frame.width - max(0, numberOfCellsPerRow - 1)*horizontalSpacing)/numberOfCellsPerRow
            flowLayout.itemSize = CGSize(width: cellWidth, height: cellWidth)
        directSearchBar.delegate = self
        ItemsCollectionsView.delegate = self
        ItemsCollectionsView.dataSource = self
            
    }
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
}
    

// MARK:- UICollectionView datasource and delegate methods

extension DirectFromFarmController: UICollectionViewDataSource,UICollectionViewDelegate {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! DirectFarmViewCell
        cell.directLbl.text = itemsArray[indexPath.row]
        cell.directImg.image = UIImage(named:imagesArray[indexPath.row])
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
                let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "DetailCookViewController") as! DetailCookViewController
        
                let strImageName = imagesArray[indexPath.row]
               let strLblName = itemsArray[indexPath.row]
                ViewController.strImageName = strImageName
               ViewController.strLblName = strLblName
        
        self.navigationController?.pushViewController(ViewController, animated: true)
        
        print(indexPath.row)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {

        let yourWidth = collectionView.bounds.width/3.0
        let yourHeight = yourWidth

        return CGSize(width: yourWidth, height: yourHeight)

    }
}






