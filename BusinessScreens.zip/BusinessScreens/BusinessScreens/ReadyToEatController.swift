//
//  ReadyToEatController.swift
//  tastyFingers
//
//  Created by Brahmaiah Chowdary on 08/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class ReadyToEatController: UIViewController,UISearchBarDelegate {
    
    let imagesArray1 = ["AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut"]
    let itemsArray1 = ["AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut","AluBajji","AluFry","CholeMasala","KaleSubzi","LadiesfingerFry","Mutter-Paneer","paneer_jalfrezi","Ricechickpeascut"]
    
    @IBOutlet weak var eatSearchBar: UISearchBar!
    @IBOutlet weak var itemsCollectionsView1: UICollectionView!
     let numberOfCellsPerRow: CGFloat = 3
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let flowLayout = itemsCollectionsView1?.collectionViewLayout as? UICollectionViewFlowLayout {
            let horizontalSpacing = flowLayout.scrollDirection == .horizontal ? flowLayout.minimumInteritemSpacing : flowLayout.minimumLineSpacing
            let cellWidth = (view.frame.width - max(0, numberOfCellsPerRow - 1)*horizontalSpacing)/numberOfCellsPerRow
            flowLayout.itemSize = CGSize(width: cellWidth, height: cellWidth)
            
            eatSearchBar.delegate = self
            itemsCollectionsView1.delegate = self
            itemsCollectionsView1.dataSource = self
    }
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
        
        
// MARK:- UICollectionView datasource and delegate methods

extension ReadyToEatController: UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemsArray1.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell1 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as! ReadyToEatCell
        cell1.eatLbl.text = itemsArray1[indexPath.row]
        cell1.eatImg.image = UIImage(named:imagesArray1[indexPath.row])
        return cell1
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "DetailCookViewController") as! DetailCookViewController
        
        let strImageName = imagesArray1[indexPath.row]
        let strLblName = itemsArray1[indexPath.row]
        ViewController.strImageName = strImageName
        ViewController.strLblName = strLblName
        self.navigationController?.pushViewController(ViewController, animated: true)
        
        print(indexPath.row)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let yourWidth = collectionView.bounds.width/3.0
        let yourHeight = yourWidth
        
        return CGSize(width: yourWidth, height: yourHeight)
        
}
}
        
        

