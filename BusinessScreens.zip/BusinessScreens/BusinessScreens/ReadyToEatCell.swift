//
//  ReadyToEatCell.swift
//  tastyFingers
//
//  Created by Brahmaiah Chowdary on 08/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class ReadyToEatCell: UICollectionViewCell {
    
    @IBOutlet weak var eatImg: UIImageView!
    
    @IBOutlet weak var eatLbl: UILabel!
}
