//
//  ReadyToCookCell.swift
//  tastyFingers
//
//  Created by Brahmaiah Chowdary on 08/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class ReadyToCookCell: UICollectionViewCell {
    @IBOutlet weak var cookImg: UIImageView!
    
    @IBOutlet weak var cookLbl: UILabel!
    
}
