//
//  ViewController.swift
//  RegView
//
//  Created by Brahmaiah Chowdary on 24/10/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.


import UIKit
import Alamofire

class Businessregistration: BaseViewController,UITextFieldDelegate {
    
    var getName = String()
    
    // Mark:- Outlets
    @IBOutlet weak var customerName: UILabel!
    @IBOutlet weak var businessLocation: UITextField!
    @IBOutlet weak var businessName: UITextField!
    @IBOutlet weak var itemName: UITextField!
   
    @IBOutlet weak var offNumber: UITextField!
    @IBOutlet weak var addItemBtn: UIButton!
    
    
      let url = URL(string: "http://www.tastyfingers.in:88/Android/Api.php?apicall=BusiRegistration")!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        customerName.text = String(getName)
       
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addItemAction(_ sender: Any) {
        if self.validated() {
            
            let parameters1: Parameters=[
                "name":businessName.text!,
                "location":businessLocation.text!,
                "phone":offNumber.text!
            ]
            //Sending http post request
//            Alamofire.request(url, method: .post, parameters: parameters1).responseJSON
//                {
//                    response in
//                    print(response)
            Alamofire.request(url, method: .post, parameters: nil, encoding: JSONEncoding.default)
                .responseJSON { response in
                    print(response)
                    // to get status code
                    if let status = response.response?.statusCode {
                        switch(status){
                        case 201:
                            print("example success")
                        default:
                            print("error with response status: \(status)")
                        
                        }
                    //getting the json value from the server
                        if let array = response.result.value as? [[String: Any]] {
                           
                            //If you want array of task id you can try like
                            var taskArray = [String]()
                            print(taskArray)
                        }
                        
//
//                        if let result = response.result.value {
//
//                        //converting it as NSDictionary
//                        let jsonData = result as! NSDictionary
//
//                        //displaying the message
//                        print(jsonData)
//
//                    }
                    }
        
        let alert = UIAlertController(title:"**note**",message:"YourFarmDetailsAreSaved",preferredStyle:UIAlertControllerStyle.alert)
      alert.addAction(UIAlertAction(title: "Ok", style:.default, handler:{_ in
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let PVC = sb.instantiateViewController(withIdentifier: "PostViewController") as!PostViewController
        PVC.getItem = self.itemName.text!
        self.navigationController?.pushViewController(PVC, animated: true)
      }))
        alert.addAction(UIAlertAction(title: "Cancel", style:.default, handler: nil))
       self.present(alert, animated: true, completion: nil)
    }
    }
        func viewWillAppear(_ animated: Bool) {
        addSlideMenuButton()
        customerName.text = String(getName)
    }
    }
    // Mark: Validation
    
    func validated() -> Bool {
       
         if self.businessLocation.text!.isEmpty || !AppHelper.isTrimmed(text: self.businessLocation.text!)
        {
            showAlert(title:"" , message: "Enter BusinessLocation")
            return false
        }
        else if !AppHelper.isRemoveSpecialCharactersFromString(text: self.businessLocation.text!)
        {
            showAlert(title:"" , message: "Enter valid BusinessLocation")
            return false
        }
        if self.businessName.text!.isEmpty || !AppHelper.isTrimmed(text: self.businessName.text!)
        {
            showAlert(title:"" , message: "Enter BusinessName")
            return false
            
        } else if !AppHelper.isRemoveSpecialCharactersFromString(text: self.businessName.text!) {
            
            showAlert(title:"" , message: "Enter valid BusinessName")
            return false
            
        }
         if self.offNumber.text!.isEmpty || !AppHelper.isTrimmed(text: self.offNumber.text!)
        {
            showAlert(title:"" , message: "Enter Your OfficeNumber" )
            return false
        }
        
        else if self.offNumber.text!.count > 14
        {
            showAlert(title:"" , message: "offNumber should be less than 14")
            return false
        }
        return true
}
    
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
}

