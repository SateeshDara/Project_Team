//
//  PopUpViewController.swift
//  BusinessScreens
//
//  Created by chennakesavulu on 08/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class PopUpViewController: UIViewController {
    
    // Mark:-Outlets
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var quantityLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    @IBOutlet weak var itemLabel: UILabel!
    @IBOutlet weak var bestLabel: UILabel!
    @IBOutlet weak var previewImage: UIImageView!
    @IBOutlet weak var vegnonvegLabel: UILabel!
    
    var getImage : UIImage?
    var getName = String()
    var getCost = String()
    var getUnit = String()
    var getQuantity = String()
    var getavlDate = String()
    var getbestBefore = String()
    var getItemFor = String()
    var getType = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.view.backgroundColor = #colorLiteral(red: 0.2685501277, green: 0.2368842959, blue: 0.05491947383, alpha: 0.9928028682)
    self.navigationController?.isNavigationBarHidden = true
        
        previewImage.image = getImage
        
        nameLabel.text = String(getName)
        costLabel.text = String(getCost) + "per 1" + String(getUnit)
        dateLabel.text = String(getavlDate)
        quantityLabel.text = String(getQuantity) + String(getUnit) + "'s"
        itemLabel.text = String(getItemFor)
        bestLabel.text = String(getbestBefore)
        vegnonvegLabel.text = String(getType)
        

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }
  
    @IBAction func submitAction(_ sender: Any) {
        let alert=UIAlertController(title:"Successfully Item Submitted"  , message:"Dou you want add one more Item Just Click 'OK' Then AddItem" , preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style:.default, handler: { _ in
          
            let sb = UIStoryboard(name: "Main", bundle: nil)
            let VC = sb.instantiateViewController(withIdentifier: "Businessregistration") as!Businessregistration
            self.navigationController?.pushViewController(VC, animated: true)
            
        }))
        alert.addAction(UIAlertAction(title: "Goto MainPage", style:.default, handler:  { _ in
        } ))
        self.present(alert,animated:true,completion:nil)
    }
        @IBAction func backAction(_ sender: Any) {
     
        self.view.removeFromSuperview()
    }
    
}
