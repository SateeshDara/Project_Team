//
//  RegisterViewController.swift
//  RegView
//
//  Created by Brahmaiah Chowdary on 25/10/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit
import Alamofire

class RegisterViewController: UIViewController,UINavigationControllerDelegate,UITextFieldDelegate {

    var userType : String?
  
    //Mark:-Outlets
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var phNo: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var nationality: UITextField!
    @IBOutlet weak var adhar: UITextField!
    
 
    let url = URL(string: "http://www.tastyfingers.in:88/Android/Api.php?apicall=signup")!
   
    let UserDefault = UserDefaults.standard
//    var isFromBusiness : Bool = false
//    var isFromTransitMedia : Bool = false
//
    override func viewDidLoad() {
        super.viewDidLoad()

        
        name.delegate = self
//        phnNo.delegate = self
//        email.delegate = self
//        nationality.delegate = self
//        adhar.delegate = self
        
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // Finish Editing The Text Field
    func textFieldDidEndEditing(_ textField: UITextField) {
     
        UserDefault.set(textField.text,forKey:"Name")
        UserDefault.synchronize()
    }
    
    @IBAction func signBtn(_ sender: UIButton) {
        
       if self.validated() {
        
        let alert = UIAlertController(title:title,message:"Login Successfully.",preferredStyle:UIAlertControllerStyle.alert)
    alert.addAction(UIAlertAction(title: "Ok", style:.default, handler:{_ in
        
        if self.userType == "BusinessMan" {
        
        let business=self.storyboard?.instantiateViewController(withIdentifier: "Businessregistration") as! Businessregistration
        business.getName = self.name.text!
       self.navigationController?.pushViewController(business, animated: true)
        }
        else  {
            
            let transitmedia=self.storyboard?.instantiateViewController(withIdentifier: "TransitmediaRegistration") as! TransitmediaRegistration
      
            self.navigationController?.pushViewController(transitmedia, animated: true)
            
        }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style:.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
        
        let parameters: Parameters=[
            "username":name.text!,
            "mobile":phNo.text!,
            "email":email.text!,
            "nationality":nationality.text!,
            "aadhar":adhar.text!
        ]
        
        //Sending http post request
        Alamofire.request(url, method: .post, parameters: parameters).responseJSON
            {
                response in
                print(response)

                //getting the json value from the server
                if let result = response.result.value {
                    
                    //converting it as NSDictionary
                    let jsonData = result as! NSDictionary
                    
                    //displaying the message
                    print(jsonData)
                    
                }
        }
    }
    
    }
    // MARK:- Validations
    
    func validated() -> Bool {
        
        if self.name.text!.isEmpty || !AppHelper.isTrimmed(text: self.name.text!)
        {
            showAlert(title:"" , message: "Enter first name")
            return false
            
        } else if !AppHelper.isRemoveSpecialCharactersFromString(text: self.name.text!) {
            
            showAlert(title:"" , message: "Enter Valid first name")
            return false
            
        }
            
        else if self.phNo.text!.isEmpty || !AppHelper.isTrimmed(text: self.phNo.text!)
        {
            showAlert(title:"" , message: "Enter phone number" )
            return false

        }  else if !AppHelper.isvalidatePhoneNumber(phoneNumber: self.phNo.text!) {
            
            showAlert(title:"" , message: "Enter Valid PhoneNumber")
            return false
        }
    
        else if self.email.text!.isEmpty || !AppHelper.isTrimmed(text: self.email.text!){
            showAlert(title:"" , message: "Enter email")
            return false
            
        } else if !AppHelper.isValidEmail(email: self.email.text!)
        {
            showAlert(title:"" , message: "Enter valid email")
            return false
            
            
        }else if self.nationality.text!.isEmpty || !AppHelper.isTrimmed(text: self.nationality.text!)
        {
            showAlert(title:"" , message: "Enter nationality")
            return false
        }
        return true
    }
}
