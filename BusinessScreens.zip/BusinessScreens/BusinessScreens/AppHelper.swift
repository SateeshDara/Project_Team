//
//  AppHelper.swift
//  TastyFingersApp
//
//  Created by Appit on 06/11/18.
//  Copyright © 2018 Tasty Fingers. All rights reserved.
//

import Foundation

import UIKit


class AppHelper {


    // MARK:- Validate email
    
    class func isValidEmail(email:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: email)
    }
    
    //MARK:- Check trimming whitespaces and newlines
    
    class func isTrimmed(text:String) ->Bool {
        let whitespace = NSCharacterSet.whitespacesAndNewlines
        let trimmed = text.trimmingCharacters(in: whitespace)
        if trimmed != "" {
            return true
        }else{
            return false
        }
    }
    
  class func isvalidatePhoneNumber(phoneNumber:String) -> Bool {
 //   let characterset = CharacterSet(charactersIn:"+0123456789").inverted
//        if phoneNumber.rangeOfCharacter(from: characterset.inverted) != nil{
//            return false
//        }else {
//            return true
//        }
    let phoneNumberEx = "^[6-9]\\d{9}$" //"^[0-9]{6,14}$"
    let phoneNumberTest = NSPredicate(format:"SELF MATCHES %@", phoneNumberEx)
    return phoneNumberTest.evaluate(with: phoneNumber)
    }
    // MARK:- Remove special characters from string
    
    class func isRemoveSpecialCharactersFromString(text:String) ->Bool {
        
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ")
        if text.rangeOfCharacter(from: characterset.inverted) != nil{
            return false
        }else {
            return true
        }
    }
    
    // MARK:- Trim white spaces from string
    
    class func trimWhiteSpaces(string:String) -> String {
        
        let trimmedStr =   string.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmedStr
    }
 
}
