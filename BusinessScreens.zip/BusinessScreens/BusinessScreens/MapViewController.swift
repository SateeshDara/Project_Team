//
//  MapViewCOntroller.swift
//  BusinessScreens
//
//  Created by chennakesavulu on 13/11/18.
//  Copyright © 2018 Brahmaiah Chowdary. All rights reserved.
//

import UIKit

class MapViewController: UIViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
